import SwiftUI
import WebKit
import CryptoKit
import Observation

// MARK: - YouTube Music: Google sign-in and the personal Home / Radio pages
//
// The sign-in recipe is BitChord-iOS's: Google's own login page in a web view that looks like Safari, then the
// cookies and the page's `ytcfg` identity are lifted out, and every request is signed with SAPISIDHASH.
// shortcut: the session lives in UserDefaults, not the Keychain; move it there if the app is ever shared.

// MARK: Session

@MainActor @Observable
final class YTMAuth {
    static let shared = YTMAuth()

    struct Session: Codable, Sendable {
        var cookie: String
        var authUser: String?
        var dataSyncId: String?
        var pageId: String?
        var visitorData: String?
        var clientVersion: String?
    }

    private static let key = "ytm.session"
    private(set) var session: Session?
    var isSignedIn: Bool { session != nil }

    private init() {
        if let d = UserDefaults.standard.data(forKey: Self.key) { session = try? JSONDecoder().decode(Session.self, from: d) }
    }

    nonisolated static let loginURL = URL(string: "https://accounts.google.com/ServiceLogin?ltmpl=music&service=youtube&passive=true&continue=https%3A%2F%2Fmusic.youtube.com%2F")!
    /// Makes the web view identify as Safari, or Google may refuse the sign-in as "not secure".
    nonisolated static let userAgentSuffix = "Version/17.0 Mobile/15E148 Safari/604.1"
    nonisolated static let secretNames = ["SAPISID", "__Secure-3PAPISID", "__Secure-1PAPISID"]

    private static let probe = """
    (function () {
      try {
        if (!window.ytcfg || !window.ytcfg.get) return null;
        var get = function (k) { var v = window.ytcfg.get(k); return (v === undefined || v === null || v === '') ? null : String(v); };
        return { loggedIn: String(!!window.ytcfg.get('LOGGED_IN')), pageId: get('DELEGATED_SESSION_ID'), dataSyncId: get('DATASYNC_ID'),
                 authUser: get('SESSION_INDEX'), visitorData: get('VISITOR_DATA'), clientVersion: get('INNERTUBE_CLIENT_VERSION') };
      } catch (e) { return null; }
    })()
    """

    /// Reads the signed-in page the web view is showing. False when the page isn't signed in yet.
    func capture(from web: WKWebView) async -> Bool {
        let cookies = await web.configuration.websiteDataStore.httpCookieStore.allCookies()
        let host = "music.youtube.com"
        let header = cookies.filter { c in
            let d = c.domain.lowercased()
            return d.hasPrefix(".") ? (host == String(d.dropFirst()) || host.hasSuffix(d)) : host == d
        }.map { "\($0.name)=\($0.value)" }.joined(separator: "; ")
        let hasSecret = header.split(separator: ";").contains { e in
            let p = e.split(separator: "=", maxSplits: 1).map { $0.trimmingCharacters(in: .whitespaces) }
            return p.count == 2 && Self.secretNames.contains(p[0]) && !p[1].isEmpty
        }
        guard hasSecret, let cfg = (try? await web.evaluateJavaScript(Self.probe)) as? [String: Any], (cfg["loggedIn"] as? String) == "true" else { return false }
        func s(_ k: String) -> String? { (cfg[k] as? String).flatMap { $0.isEmpty ? nil : $0 } }
        let pageId = s("pageId")
        // DATASYNC_ID looks like "account||delegated"; the second half is the active identity.
        var sync = pageId ?? s("dataSyncId")
        if pageId == nil, let v = sync, v.contains("||") {
            let parts = v.components(separatedBy: "||")
            sync = parts.count > 1 && !parts[1].isEmpty ? parts[1] : parts[0]
        }
        let new = Session(cookie: header, authUser: s("authUser"), dataSyncId: sync, pageId: pageId, visitorData: s("visitorData"), clientVersion: s("clientVersion"))
        session = new
        if let d = try? JSONEncoder().encode(new) { UserDefaults.standard.set(d, forKey: Self.key) }
        await AppleFeedStore.shared.reload(force: true)
        return true
    }

    func signOut() async {
        session = nil
        UserDefaults.standard.removeObject(forKey: Self.key)
        let store = WKWebsiteDataStore.default()
        let records = await store.dataRecords(ofTypes: WKWebsiteDataStore.allWebsiteDataTypes())
        await store.removeData(ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(), for: records.filter { r in
            ["youtube", "google"].contains { r.displayName.contains($0) }
        })
        await AppleFeedStore.shared.reload(force: true)
    }
}

// MARK: Login screen

@MainActor
final class YTMLoginWeb: NSObject, ObservableObject, WKNavigationDelegate {
    let view: WKWebView
    @Published var ready = false

    override init() {
        let cfg = WKWebViewConfiguration()
        cfg.applicationNameForUserAgent = YTMAuth.userAgentSuffix
        view = WKWebView(frame: .zero, configuration: cfg)
        super.init()
        view.navigationDelegate = self
        view.load(URLRequest(url: YTMAuth.loginURL))
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        // Back on YouTube Music only enables "Done"; nothing is captured until you confirm, because a
        // multi-channel account may still be choosing which profile to use on that very page.
        ready = webView.url?.absoluteString.hasPrefix("https://music.youtube.com") == true
    }
}

private struct YTMWebView: UIViewRepresentable {
    let web: YTMLoginWeb
    func makeUIView(context: Context) -> WKWebView { web.view }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

struct YTMLoginSheet: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var web = YTMLoginWeb()
    @State private var notYet = false

    var body: some View {
        NavigationStack {
            YTMWebView(web: web)
                .ignoresSafeArea(edges: .bottom)
                .navigationTitle("YouTube Music")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Done") {
                            Task { if await YTMAuth.shared.capture(from: web.view) { dismiss() } else { notYet = true } }
                        }
                        .disabled(!web.ready)
                    }
                }
                .alert("Not signed in yet", isPresented: $notYet) {
                    Button("OK", role: .cancel) {}
                } message: { Text("Finish signing in until YouTube Music opens with your profile, then tap Done.") }
        }
    }
}

/// Settings row: sign in, or who you're signed in as and how to sign out.
struct YTMAccountRow: View {
    @State private var auth = YTMAuth.shared
    @State private var login = false

    var body: some View {
        Group {
            if auth.isSignedIn {
                Label("Signed in to YouTube Music", systemImage: "checkmark.circle.fill")
                Button("Sign Out", role: .destructive) { Task { await auth.signOut() } }
            } else {
                Button { login = true } label: { Label("Sign in to YouTube Music", systemImage: "person.crop.circle.badge.plus") }
            }
        }
        .sheet(isPresented: $login) { YTMLoginSheet() }
    }
}

/// Slim row at the top of Home and Radio while signed out.
struct YTMSignInBanner: View {
    @State private var auth = YTMAuth.shared
    @State private var login = false

    var body: some View {
        if !auth.isSignedIn {
            Button { login = true } label: {
                HStack(spacing: 10) {
                    Image(systemName: "person.crop.circle.badge.plus").font(.system(size: 20))
                    VStack(alignment: .leading, spacing: 1) {
                        Text("Sign in to YouTube Music").font(.system(size: 15, weight: .semibold))
                        Text("Your own mixes, albums and radio").font(.system(size: 13)).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Image(systemName: "chevron.right").font(.system(size: 13, weight: .semibold)).foregroundStyle(.tertiary)
                }
                .padding(12)
                .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color.secondary.opacity(0.15)))
                .padding(.horizontal, 20)
            }
            .buttonStyle(.plain)
            .sheet(isPresented: $login) { YTMLoginSheet() }
        }
    }
}

// MARK: - Requests

nonisolated enum YTMClient {
    static let origin = "https://music.youtube.com"
    static let fallbackVersion = "1.20250101.01.00"

    /// `SAPISIDHASH <ts>_<sha1("<ts> <sapisid> <origin>")>`
    static func authorization(cookie: String, now: Date = Date()) -> String? {
        var jar: [String: String] = [:]
        for e in cookie.split(separator: ";") {
            let p = e.split(separator: "=", maxSplits: 1).map { $0.trimmingCharacters(in: .whitespaces) }
            if p.count == 2 { jar[p[0]] = p[1] }
        }
        guard let secret = YTMAuth.secretNames.compactMap({ jar[$0] }).first else { return nil }
        let ts = Int(now.timeIntervalSince1970)
        let hash = Insecure.SHA1.hash(data: Data("\(ts) \(secret) \(origin)".utf8)).map { String(format: "%02x", $0) }.joined()
        return "SAPISIDHASH \(ts)_\(hash)"
    }

    static func post(_ endpoint: String, _ extra: [String: Any], session: YTMAuth.Session?) async -> [String: Any]? {
        guard let url = URL(string: "\(origin)/youtubei/v1/\(endpoint)?prettyPrint=false") else { return nil }
        let version = session?.clientVersion ?? fallbackVersion
        var client: [String: Any] = ["clientName": "WEB_REMIX", "clientVersion": version, "hl": "en", "gl": (Locale.current.region?.identifier ?? "US")]
        if let v = session?.visitorData { client["visitorData"] = v }
        var context: [String: Any] = ["client": client]
        if let sync = session?.dataSyncId { context["user"] = ["onBehalfOfUser": sync] }
        var body = extra
        body["context"] = context
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.timeoutInterval = 20
        req.httpBody = try? JSONSerialization.data(withJSONObject: body)
        for (k, v) in [
            "Content-Type": "application/json", "Origin": origin, "Referer": origin + "/", "X-Origin": origin,
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
            "X-YouTube-Client-Name": "67", "X-YouTube-Client-Version": version
        ] { req.setValue(v, forHTTPHeaderField: k) }
        if let s = session {
            req.setValue(s.cookie, forHTTPHeaderField: "Cookie")
            if let a = authorization(cookie: s.cookie) { req.setValue(a, forHTTPHeaderField: "Authorization") }
            req.setValue(s.authUser ?? "0", forHTTPHeaderField: "X-Goog-AuthUser")
            if let p = s.pageId { req.setValue(p, forHTTPHeaderField: "X-Goog-PageId") }
            if let v = s.visitorData { req.setValue(v, forHTTPHeaderField: "X-Goog-Visitor-Id") }
        }
        guard let (data, resp) = try? await URLSession.shared.data(for: req), (resp as? HTTPURLResponse)?.statusCode == 200 else { return nil }
        return (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
    }

    // MARK: Parsing (the response is a deep tree; shelves are found by their renderer names)

    private static func dict(_ v: Any?) -> [String: Any]? { v as? [String: Any] }
    private static func list(_ v: Any?) -> [[String: Any]] { (v as? [[String: Any]]) ?? [] }

    /// Every value stored under `key`, anywhere in the tree, in document order.
    private static func find(_ key: String, in node: Any?) -> [[String: Any]] {
        var out: [[String: Any]] = []
        if let d = node as? [String: Any] {
            for (k, v) in d.sorted(by: { $0.key < $1.key }) {
                if k == key, let x = v as? [String: Any] { out.append(x) } else { out += find(key, in: v) }
            }
        } else if let a = node as? [Any] {
            for v in a { out += find(key, in: v) }
        }
        return out
    }

    private static func text(_ v: Any?) -> String {
        list(dict(v)?["runs"]).compactMap { $0["text"] as? String }.joined()
    }

    private static func thumb(_ v: Any?) -> String? {
        func urls(_ n: Any?) -> [[String: Any]] {
            if let d = n as? [String: Any] {
                if let a = d["thumbnails"] as? [[String: Any]] { return a }
                for x in d.values { let r = urls(x); if !r.isEmpty { return r } }
            } else if let a = n as? [Any] { for x in a { let r = urls(x); if !r.isEmpty { return r } } }
            return []
        }
        return urls(v).last?["url"] as? String
    }

    /// "Album • Artist • 2024" → "Artist • 2024": the leading word only names the kind.
    private static func clean(_ s: String) -> String {
        for k in ["Song", "Album", "Single", "EP", "Playlist", "Video", "Artist", "Mix"] where s.hasPrefix(k + " • ") { return String(s.dropFirst(k.count + 3)) }
        return s
    }

    private static func item(_ node: [String: Any]) -> FeedItem? {
        if let r = dict(node["musicTwoRowItemRenderer"]) {
            let title = text(r["title"])
            guard !title.isEmpty else { return nil }
            let sub = text(r["subtitle"])
            let art = thumb(r["thumbnailRenderer"])
            let nav = dict(r["navigationEndpoint"])
            if let vid = dict(nav?["watchEndpoint"])?["videoId"] as? String {
                return FeedItem(id: vid, kind: .song, title: title, subtitle: clean(sub), art: art, rank: nil)
            }
            if let pl = dict(nav?["watchPlaylistEndpoint"])?["playlistId"] as? String {
                return FeedItem(id: "yt:" + pl, kind: .station, title: title, subtitle: clean(sub), art: art, rank: nil)
            }
            guard let b = dict(nav?["browseEndpoint"])?["browseId"] as? String else { return nil }
            let kind: FeedItem.Kind = b.hasPrefix("MPRE") ? .album : b.hasPrefix("UC") ? .artist : .playlist
            return FeedItem(id: "yt:" + b, kind: kind, title: title, subtitle: clean(sub), art: art, rank: nil)
        }
        if let r = dict(node["musicResponsiveListItemRenderer"]) {
            let cols = list(r["flexColumns"]).map { text(dict($0["musicResponsiveListItemFlexColumnRenderer"])?["text"]) }
            guard let title = cols.first, !title.isEmpty else { return nil }
            let vid = (dict(r["playlistItemData"])?["videoId"] as? String)
                ?? (find("watchEndpoint", in: r).first?["videoId"] as? String)
            guard let vid else { return nil }
            return FeedItem(id: vid, kind: .song, title: title, subtitle: cols.dropFirst().first.map(clean) ?? "", art: thumb(r["thumbnail"]), rank: nil)
        }
        return nil
    }

    static func shelves(_ root: [String: Any]?) -> [FeedShelf] {
        guard let root else { return [] }
        var out: [FeedShelf] = []
        for (i, s) in find("musicCarouselShelfRenderer", in: root).enumerated() {
            let head = dict(dict(s["header"])?["musicCarouselShelfBasicHeaderRenderer"])
            let title = text(head?["title"])
            let items = list(s["contents"]).compactMap(item)
            if !title.isEmpty, !items.isEmpty {
                out.append(FeedShelf(id: "yt.\(i).\(title)", title: title, subtitle: text(head?["strapline"]).isEmpty ? nil : text(head?["strapline"]), items: items))
            }
        }
        return out
    }

    /// Moods & genres become tappable stations: a mix built from the extensions.
    static func moods(_ root: [String: Any]?) -> [FeedShelf] {
        guard let root else { return [] }
        var out: [FeedShelf] = []
        for (i, g) in find("gridRenderer", in: root).enumerated() {
            let title = text(dict(dict(g["header"])?["gridHeaderRenderer"])?["title"])
            let items: [FeedItem] = list(g["items"]).compactMap { n in
                guard let b = dict(n["musicNavigationButtonRenderer"]) else { return nil }
                let t = text(b["buttonText"])
                return t.isEmpty ? nil : FeedItem(id: "mood:" + t, kind: .station, title: t, subtitle: "Mix", art: nil, rank: nil)
            }
            if !items.isEmpty { out.append(FeedShelf(id: "yt.mood.\(i)", title: title.isEmpty ? "Moods & Genres" : title, subtitle: nil, items: items)) }
        }
        return out
    }

    // MARK: Pages

    static func home(session: YTMAuth.Session?) async -> [FeedShelf] { shelves(await post("browse", ["browseId": "FEmusic_home"], session: session)) }
    static func newReleases(session: YTMAuth.Session?) async -> [FeedShelf] { shelves(await post("browse", ["browseId": "FEmusic_new_releases"], session: session)) }
    static func radio(session: YTMAuth.Session?) async -> [FeedShelf] {
        let m = moods(await post("browse", ["browseId": "FEmusic_moods_and_genres"], session: session))
        let mixes = await home(session: session).filter { $0.title.localizedCaseInsensitiveContains("mix") || $0.title.localizedCaseInsensitiveContains("radio") }
        return mixes + m
    }

    /// Songs of a "yt:" album or playlist.
    static func tracks(of item: FeedItem, session: YTMAuth.Session?) async -> [FeedItem] {
        var id = String(item.id.dropFirst(3))
        if item.kind == .playlist, !id.hasPrefix("VL") { id = "VL" + id }
        guard let root = await post("browse", ["browseId": id], session: session) else { return [] }
        let rows = find("musicResponsiveListItemRenderer", in: root)
        var out: [FeedItem] = []
        for r in rows {
            guard var it = Self.item(["musicResponsiveListItemRenderer": r]) else { continue }
            if it.art == nil { it.art = item.art }
            if it.subtitle.isEmpty || item.kind == .album { it.subtitle = item.subtitle.components(separatedBy: " • ").first ?? item.subtitle }
            it.rank = out.count + 1
            out.append(it)
        }
        return out
    }
}
